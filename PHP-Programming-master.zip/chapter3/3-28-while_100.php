﻿<?PHP
/* while문과 do~while문의 차이
 * 이 경우, while문은 동작 안함
 */

$i = 100;

while ($i <= 10)
{
   echo $i."<br>";
}
?>
