﻿<?PHP
/* while문과 do~while문의 차이
 * 이 경우, {}내 명령문은 무조건 1번 실행
 */

$i = 100;

do
{
   echo $i."<br>";
} while ($i <= 10)
?>
