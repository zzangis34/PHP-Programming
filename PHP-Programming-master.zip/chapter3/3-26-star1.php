﻿<?PHP
/* for문 예제 : 별표 찍기 문제
 * 중첩 for 문
 */

for ($a=1; $a<=10; $a++)
{
	for ($b=1; $b<=$a; $b++)
	{
		echo "* ";
	}
	echo "<br>";
}
?>
