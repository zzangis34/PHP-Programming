﻿create table friend2(
num int not null,
name char(10),
address char(80),
tel char(20),
primary key(num)
);