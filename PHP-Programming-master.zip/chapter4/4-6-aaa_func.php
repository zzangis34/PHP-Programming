﻿<?PHP
/* 함수 예제 : 함수의 정의와 호출
 *
 */

function aaa()
{
    echo ("안녕하세요!");
}

aaa();
?>