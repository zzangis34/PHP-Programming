﻿<?PHP
/* 함수 예제 : 함수를 이용한 두 수의 합 계산
 *
 */

function plus($a, $b)
{
        $c = $a + $b;
        echo $c;
}

plus(15, 25);
echo "<br>";
plus(3500, 1500);

?> 