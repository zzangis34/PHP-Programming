﻿<?PHP
/* 상수 constant
 * 문자열, 자연수, 소수
 * c언어와 달리, 자료형 선언 불필요
 */

$a = "자동차";
echo "<br>";     	// 줄바꿈
echo $a;

$a = "기차";
echo "<br>"; 	// 줄바꿈
echo $a;

$a = 1000;
echo "<br>";		// 줄바꿈
echo $a;
?>
