<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 2019-03-12
 * Time: 오후 4:33
 */

echo "Hello World"

?>