﻿<?
//	phpinfo();
	echo "aaa";
    echo "aaa";

?>